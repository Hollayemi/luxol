import axios, { type AxiosRequestConfig } from "axios";
import type { BaseQueryFn } from "@reduxjs/toolkit/query";
import { isApiFailure, isApiSuccess, toApiError } from "./errors";
import type { ApiError, ApiSuccess } from "./types";

/**
 * Point this at your NestJS server, e.g. http://localhost:4000
 * (include your global prefix if you use one, e.g. http://localhost:4000/api).
 */
export const axiosInstance = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  timeout: 15_000,
  headers: { "Content-Type": "application/json" },
});

export type AxiosBaseQueryArgs = {
  url: string;
  method?: AxiosRequestConfig["method"];
  data?: AxiosRequestConfig["data"];
  params?: AxiosRequestConfig["params"];
  headers?: Record<string, string>;
};

/**
 * RTK Query base query built on axios.
 *
 * - Adds the Bearer token from the session slice (kept in sync with next-auth).
 * - Resolves with the API's success envelope: { success, message, data }.
 * - Rejects with an ApiError (see types/api.ts), never a raw axios error.
 */
const axiosBaseQuery =
  (): BaseQueryFn<AxiosBaseQueryArgs, unknown, ApiError> =>
  async ({ url, method = "GET", data, params, headers }, { getState, signal }) => {
    const token = (
      getState() as { session?: { accessToken?: string | null } }
    ).session?.accessToken;

    try {
      const response = await axiosInstance.request({
        url,
        method,
        data,
        params,
        signal,
        headers: {
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
          ...headers,
        },
      });

      const body: unknown = response.data;

      // The API answered 2xx but flagged an error
      if (isApiFailure(body)) return { error: toApiError(body) };

      if (isApiSuccess(body)) return { data: body };

      // Unexpected shape (e.g. 204 No Content): still hand back an envelope
      const fallback: ApiSuccess<unknown> = {
        success: true,
        message: "",
        data: body ?? null,
      };
      return { data: fallback };
    } catch (error) {
      return { error: toApiError(error) };
    }
  };

export default axiosBaseQuery;
