import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { MEMBERSHIP_PLANS } from "@/app/data/subscription-data";
import CheckoutClient from "./CheckoutClient";

export const metadata: Metadata = {
  title: "Membership Subscription | Luxol Supermarket",
};

const container = "mx-auto w-full max-w-[1240px] px-4 sm:px-6";

type SearchParams = Promise<{ plan?: string | string[] }>;

function first(v?: string | string[]) {
  return Array.isArray(v) ? v[0] : v;
}

export default async function SubscriptionCheckoutPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const sp = await searchParams;
  const planId = first(sp.plan);
  const plan = MEMBERSHIP_PLANS.find((p) => p.id === planId);

  if (!plan) notFound();

  return (
    <div>
      <section className="bg-[#f2f2f0] py-10 text-center sm:py-12">
        <div className={container}>
          <h1 className="text-3xl font-bold text-neutral-900 sm:text-4xl">
            Membership Subscription
          </h1>
          <nav aria-label="Breadcrumb" className="mt-3 text-sm">
            <ol className="flex items-center justify-center gap-x-2 text-neutral-600">
              <li>
                <Link href="/" className="hover:text-luxol-green">
                  Home
                </Link>
              </li>
              <li aria-hidden="true">/</li>
              <li aria-current="page" className="font-medium text-luxol-green">
                Subscribe
              </li>
            </ol>
          </nav>
        </div>
      </section>

      <div className={`${container} py-10 sm:py-14`}>
        <CheckoutClient plan={plan} />
      </div>
    </div>
  );
}
